﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class Arrayb
    {
       // public static ArrayList arrbooks = new ArrayList();
       // public static ArrayList idauthor = new ArrayList();// רשימת עזר
        public static ArrayList idbooks = new ArrayList();// רשימת עזר
        public static ArrayList bookslist = new ArrayList();// כל הספרים ברשימה ממוינת
        public static ArrayList authorsnamelist = new ArrayList();//כל השמות של הכותבים
        public static Hashtable idbookspath = new Hashtable();// כל השמות של הספרים של כותב לפי "מפתח" תז כותב
        public static Hashtable bookslistpath = new Hashtable();// כל הכתובות של הספרים לפי "מפתח" השם שלהם
        public static Hashtable autherslistpath = new Hashtable();//כל הכותבים לפי שם הספר
        public static Hashtable autherslistid = new Hashtable();//כל תז כותב  לפי שם 
        public static void arrybookslaod()
        {


                idbookspath.Clear();
                authorsnamelist.Clear();
                autherslistpath.Clear();
                bookslist.Clear();
                bookslistpath.Clear();
                autherslistid.Clear();

            foreach (object id in Directory.GetDirectories("authors"))
            {
                idbooks.Clear();
                idbookspath[Path.GetFileName(id.ToString())] = Directory.GetDirectories("authors/" + Path.GetFileName(id.ToString()) + "/books");
                authorsnamelist.Add(File.ReadAllText(id.ToString() + "/details/FullName"));
                idbooks.Add(Directory.GetDirectories(id.ToString() + "/BOOKS"));
                autherslistid[File.ReadAllText(id.ToString() + "/details/FullName")] = Path.GetFileName(id.ToString());
                foreach (Array book in idbooks)
                {
                    foreach (object item in book)
                    {
                        autherslistpath[Path.GetFileName(item.ToString())] = File.ReadAllText(id.ToString() + "/details/FullName");
                        bookslist.Add(Path.GetFileName(item.ToString()));
                        bookslistpath[Path.GetFileName(item.ToString())] = item.ToString();
                    }
                }

            }
            bookslist.Sort();

        }
    }
}
