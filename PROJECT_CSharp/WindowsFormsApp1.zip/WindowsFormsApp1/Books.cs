﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    // Declare the enum outside of any class so it's accessible everywhere
    public enum Category
    {
        Fiction,
        NonFiction,
        Science,
        Biography,
        Fantasy,
        Mystery
    }

    // Book class
    internal class Books
    {
        private string bookname;
        private string category;
        private int amount;
        private float price;
        private string aboutbook;

        public string Bookname
        {
            get => bookname;
            set
            {
                if (!IsValidBookName(value))
                {
                    throw new ArgumentException("Invalid book name");
                }
                bookname = value;
            }
        }

        public string Category
        {
            get => category;
            set => category = value;
        }

        public int Amount
        {
            get => amount;
            set => amount = value;
        }

        public float Price
        {
            get => price;
            set => price = value;
        }

        public string Aboutbook
        {
            get => aboutbook;
            set => aboutbook = value;
        }

        private bool IsValidBookName(string bookname)
        {
            return !string.IsNullOrEmpty(bookname);
        }
        public bool checkname(string name)
        {
            foreach (string named in Arrayb.bookslist)
            {
                if (name == named)
                {
                    return false;
                }
            }
            return true;
        }
        public void addproduct(string id)
        {

            Directory.CreateDirectory("authors/" + id + "/books/" + bookname);
            File.AppendAllText("authors/" + id + "/books/" + bookname + "/Bookname", bookname);
            File.AppendAllText("authors/" + id + "/books/" + bookname + "/category", category);
            File.AppendAllText("authors/" + id + "/books/" + bookname + "/amount", amount.ToString());
            File.AppendAllText("authors/" + id + "/books/" + bookname + "/price", price.ToString());


        }
    }

}
