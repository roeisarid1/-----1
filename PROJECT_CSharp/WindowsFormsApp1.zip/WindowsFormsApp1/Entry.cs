﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Entry : Form
    {
        public Entry()
        {
            InitializeComponent();
        }


        private void butent_Click(object sender, EventArgs e)
        {
            try
            {
                if (cheaut.Checked == true)
                {
                    string AuthorIdInput = texid.Text;
                    bool AuthorIdInSystem = Directory.Exists("authors/" + AuthorIdInput);
                    if (AuthorIdInSystem == false)
                    {
                        MessageBox.Show("Id doesn't exsist in the system");
                    }
                    else
                    {
                        string AuthorPassInput = texpas.Text;
                        string PasswordFile = File.ReadAllText("authors/" + AuthorIdInput + "/details" + "/Password");
                        if (AuthorPassInput == PasswordFile)
                        {
                            main main = new main(texid.Text, true);
                            Arrayb.arrybookslaod();
                            main.Show();
                            this.Close();

                        }
                        else
                        {
                            MessageBox.Show("The Id doesnt mach the password ");

                        }

                    }
                }
                else
                {
                    string UserIdInput = texid.Text;
                    bool IdexistsInSystem = Directory.Exists("users/" + UserIdInput);
                    if (IdexistsInSystem == false)
                    {
                        MessageBox.Show("Id dont exsist in the system");
                    }
                    else
                    {
                        string UserPassInput = texpas.Text;
                        string UserPassFile = File.ReadAllText("users/" + UserIdInput + "/details" + "/Password");
                        if (UserPassInput == UserPassFile)
                        {
                            Arrayb.arrybookslaod();
                            main main = new main(texid.Text, false);

                            main.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("The Id doesnt mach the password ");
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("all details must be filled and valid ");
            }
        }

        private void butope_Click(object sender, EventArgs e)
        {
            Newuser newuser = new Newuser();
            newuser.Show();
        }
    }
}
