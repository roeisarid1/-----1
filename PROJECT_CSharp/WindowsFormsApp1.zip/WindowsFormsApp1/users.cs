﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class users
    {
        private string id;
        private string fullname;
        private string password;
        private DateTime birthday;


        public string Id
        {
            get
            {
                return id;
            }
            set
            {
                if (checkidvalid(value))
                {
                    id = value;
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }

        public string Fullname
        {
            get
            {
                return fullname;
            }
            set
            {
                if (checkifallletters(value) == true)
                {
                    fullname = value;
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }

        public DateTime Birthday
        {
            get
            {
                return birthday;
            }
            set
            {
                if (checkifabove16(value) == true)
                {
                    birthday = value;
                }
                else
                {
                    throw new ArgumentException();
                }
            }
        }

        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        public bool checkidvalid(string id)
        {
            return !string.IsNullOrEmpty(id) && id.Length == 9;
        }
        public bool checkifallletters(string id)
        {
            return id.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }
        public bool checkifabove16(DateTime date)
        {
            DateTime today = DateTime.Today;
            DateTime sixteeyearsago = today.AddYears(-16);
            return date <= sixteeyearsago;

        }
        public bool checkidinsystem(string id)
        {

            bool IdexistsInSystem = Directory.Exists("users/" + id);
            return IdexistsInSystem;
        }


    }


}
