﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.ControlerPags;

namespace WindowsFormsApp1
{
    public partial class main : Form
    {
        string id;
        bool isAuthor;
        public main(string id, bool isAuthor)
        {
            this.id = id;
            this.isAuthor = isAuthor;
            InitializeComponent();

        }
        private void addUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            pancon.Controls.Clear();
            pancon.Controls.Add(userControl);
            userControl.BringToFront();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UserControl1 us1 = new UserControl1();
            addUserControl(us1);
        }


        private void button3_Click(object sender, EventArgs e)
        {
            if (isAuthor)
            {
                UserControl3 us3 = new UserControl3(id);
                addUserControl(us3);
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
                if (isAuthor)
                {
                 UserControl4 us4 = new UserControl4(id);
                 addUserControl(us4);

                }
        
        }

        
    }
}
