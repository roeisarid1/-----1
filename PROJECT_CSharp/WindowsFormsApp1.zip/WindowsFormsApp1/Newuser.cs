﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WindowsFormsApp1
{
    public partial class Newuser : Form
    {
        users user = new users();
        static bool validid = false; // a contition that must happen to enter a user do the system 
        static bool validfullname = false;// a contition that must happen to enter a user do the system 
        static bool validdateofbirth = false;// a contition that must happen to enter a user do the system 
        public Newuser()
        {
            InitializeComponent();
            labeid.Hide();
            IdNotValid.Hide();
            FullNameNotValid.Hide();
            DOBnotvalidlbl.Hide();
        }
   

        private void texID_Leave(object sender, EventArgs e)
        {
            bool errorCaught = false;
            try { user.Id = texID.Text; }
            catch (ArgumentException)
            { errorCaught = true; IdNotValid.Show(); }
            if (errorCaught == false)
            {
                validid = true;
            }
            string UserIdInput = texID.Text;
            bool IdexistsInSystem = Directory.Exists("users/" + UserIdInput);
            bool IdexistsInSystemauthors = Directory.Exists("authors/" + UserIdInput);
            if (IdexistsInSystem || IdexistsInSystemauthors == true)
            {
                validid = false;
                labeid.Show();
            }

        }

        private void texID_Click(object sender, EventArgs e)
        {

            labeid.Hide();
            IdNotValid.Hide();
        }

        private void texfir_Leave_1(object sender, EventArgs e)
        {
            bool errorCaught = false;
            try { user.Fullname = texfir.Text; }
            catch (ArgumentException)
            { errorCaught = true; FullNameNotValid.Show(); }
            if (errorCaught == false) // if you didnt catch any error then the full name is valid
            {
                validfullname = true;
            }
        }

        private void texfir_Click_1(object sender, EventArgs e)
        {
            FullNameNotValid.Hide();
        }

        private void confirmbtn_Click_1(object sender, EventArgs e)
        {
            DOBnotvalidlbl.Hide();
            bool errorCaught = false;
            try { user.Birthday = datbir.Value; }
            catch (ArgumentException)
            { errorCaught = true; DOBnotvalidlbl.Show(); }
            if (errorCaught == false) // if you didnt catch any error then the full name is valid
            {
                confirnedbtn.Visible = true;
                validdateofbirth = true;
            }

        }

        private void butent_Click(object sender, EventArgs e)
        {
            confirnedbtn.Visible = false;

            if (validid && validfullname && validdateofbirth)// case all were valid lets insert the user to the system 
            {
                Directory.CreateDirectory("users/" + texID.Text);
                Directory.CreateDirectory("users/" + texID.Text + "/details");
                Directory.CreateDirectory("users/" + texID.Text + "/ordersOfMe");
                File.AppendAllText("users/" + texID.Text + "/details"+ "/Id", texID.Text);
                File.AppendAllText("users/" + texID.Text + "/details" + "/FullName", texfir.Text);
                File.AppendAllText("users/" + texID.Text + "/details" + "/Password", texpas.Text);
                File.AppendAllText("users/" + texID.Text + "/details" + "/Birthday", datbir.ToString());
                MessageBox.Show($"{user.Fullname} , You have been added to the system successfully.");
                this.Close();

            }
            else
            {
                MessageBox.Show("All details must be valid");
            }

        }

        private void cheaut_Click(object sender, EventArgs e)
        {   if (cheaut.Checked)
            { 
            butent.Hide();
            btnaut.Visible = true;
            labpascoa.Visible = true;
            texpascoa.Visible = true;
            }
            else
            {
                butent.Show();

                btnaut.Visible = false;
                labpascoa.Visible = false;
                texpascoa.Visible = false;

            }
        }

        private void btnaut_Click(object sender, EventArgs e)
        {
            if (texpascoa.Text != "1234")
            {
                incorrectcode.Visible = true;
            }
            else if(validid && validfullname && validdateofbirth)// case all were valid lets insert the user to the system )
            {
                Directory.CreateDirectory("authors/" + texID.Text);
                Directory.CreateDirectory("authors/" + texID.Text + "/books");
                Directory.CreateDirectory("authors/" + texID.Text + "/ordersFromMe");
                Directory.CreateDirectory("authors/" + texID.Text + "/ordersOfMe");
                Directory.CreateDirectory("authors/" + texID.Text + "/details");
                File.AppendAllText("authors/" + texID.Text + "/details" + "/Id", texID.Text);
                File.AppendAllText("authors/" + texID.Text + "/details" + "/FullName", texfir.Text);
                File.AppendAllText("authors/" + texID.Text + "/details" + "/Password", texpas.Text);
                File.AppendAllText("authors/" + texID.Text + "/details" + "/Birthday", datbir.ToString());
                MessageBox.Show($"{user.Fullname} , You have been added to the system successfully.");
                this.Close();
            }
        }
    }
}
