﻿namespace WindowsFormsApp1
{
    partial class Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Entry));
            this.panel1 = new System.Windows.Forms.Panel();
            this.labwel2 = new System.Windows.Forms.Label();
            this.labwel1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.butope = new System.Windows.Forms.Button();
            this.butent = new System.Windows.Forms.Button();
            this.cheaut = new System.Windows.Forms.CheckBox();
            this.labid = new System.Windows.Forms.Label();
            this.labpas = new System.Windows.Forms.Label();
            this.texid = new System.Windows.Forms.TextBox();
            this.texpas = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Controls.Add(this.labwel2);
            this.panel1.Controls.Add(this.labwel1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(692, 111);
            this.panel1.TabIndex = 0;
            // 
            // labwel2
            // 
            this.labwel2.AutoSize = true;
            this.labwel2.Font = new System.Drawing.Font("Cascadia Mono", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labwel2.Location = new System.Drawing.Point(186, 62);
            this.labwel2.Name = "labwel2";
            this.labwel2.Size = new System.Drawing.Size(476, 32);
            this.labwel2.TabIndex = 2;
            this.labwel2.Text = "Stories Directly from the Author.";
            // 
            // labwel1
            // 
            this.labwel1.AutoSize = true;
            this.labwel1.Font = new System.Drawing.Font("Cascadia Mono", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labwel1.Location = new System.Drawing.Point(150, 22);
            this.labwel1.Name = "labwel1";
            this.labwel1.Size = new System.Drawing.Size(364, 32);
            this.labwel1.TabIndex = 1;
            this.labwel1.Text = "Write, Publish, Receive: ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 111);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(124, 324);
            this.panel2.TabIndex = 1;
            // 
            // butope
            // 
            this.butope.Location = new System.Drawing.Point(460, 337);
            this.butope.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butope.Name = "butope";
            this.butope.Size = new System.Drawing.Size(146, 32);
            this.butope.TabIndex = 2;
            this.butope.Text = "open a new user";
            this.butope.UseVisualStyleBackColor = true;
            this.butope.Click += new System.EventHandler(this.butope_Click);
            // 
            // butent
            // 
            this.butent.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.butent.Location = new System.Drawing.Point(190, 317);
            this.butent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butent.Name = "butent";
            this.butent.Size = new System.Drawing.Size(115, 52);
            this.butent.TabIndex = 3;
            this.butent.Text = "Enter";
            this.butent.UseVisualStyleBackColor = true;
            this.butent.Click += new System.EventHandler(this.butent_Click);
            // 
            // cheaut
            // 
            this.cheaut.AutoSize = true;
            this.cheaut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cheaut.Location = new System.Drawing.Point(189, 270);
            this.cheaut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cheaut.Name = "cheaut";
            this.cheaut.Size = new System.Drawing.Size(157, 24);
            this.cheaut.TabIndex = 4;
            this.cheaut.Text = "Author click here";
            this.cheaut.UseVisualStyleBackColor = true;
            // 
            // labid
            // 
            this.labid.AutoSize = true;
            this.labid.Font = new System.Drawing.Font("Britannic Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labid.Location = new System.Drawing.Point(185, 168);
            this.labid.Name = "labid";
            this.labid.Size = new System.Drawing.Size(33, 25);
            this.labid.TabIndex = 5;
            this.labid.Text = "ID";
            // 
            // labpas
            // 
            this.labpas.AutoSize = true;
            this.labpas.Font = new System.Drawing.Font("Britannic Bold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpas.Location = new System.Drawing.Point(185, 225);
            this.labpas.Name = "labpas";
            this.labpas.Size = new System.Drawing.Size(105, 25);
            this.labpas.TabIndex = 6;
            this.labpas.Text = "Password";
            // 
            // texid
            // 
            this.texid.Location = new System.Drawing.Point(357, 168);
            this.texid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texid.Name = "texid";
            this.texid.Size = new System.Drawing.Size(151, 22);
            this.texid.TabIndex = 7;
            // 
            // texpas
            // 
            this.texpas.Location = new System.Drawing.Point(357, 232);
            this.texpas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texpas.Name = "texpas";
            this.texpas.Size = new System.Drawing.Size(151, 22);
            this.texpas.TabIndex = 8;
            // 
            // Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 435);
            this.Controls.Add(this.butent);
            this.Controls.Add(this.texpas);
            this.Controls.Add(this.texid);
            this.Controls.Add(this.labpas);
            this.Controls.Add(this.labid);
            this.Controls.Add(this.cheaut);
            this.Controls.Add(this.butope);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximumSize = new System.Drawing.Size(713, 489);
            this.Name = "Entry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entry";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button butope;
        private System.Windows.Forms.Button butent;
        private System.Windows.Forms.Label labwel1;
        private System.Windows.Forms.CheckBox cheaut;
        private System.Windows.Forms.Label labid;
        private System.Windows.Forms.Label labpas;
        private System.Windows.Forms.TextBox texid;
        private System.Windows.Forms.TextBox texpas;
        private System.Windows.Forms.Label labwel2;
    }
}

