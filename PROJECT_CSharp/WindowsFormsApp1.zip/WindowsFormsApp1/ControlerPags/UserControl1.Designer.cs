﻿namespace WindowsFormsApp1.ControlerPags
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bookslistbox = new System.Windows.Forms.CheckedListBox();
            this.searchtextbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.searchbtn = new System.Windows.Forms.Button();
            this.alabano = new System.Windows.Forms.Label();
            this.alabpri = new System.Windows.Forms.Label();
            this.alabcat = new System.Windows.Forms.Label();
            this.alabautname = new System.Windows.Forms.Label();
            this.alabbookname = new System.Windows.Forms.Label();
            this.domamo = new System.Windows.Forms.DomainUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.labamo = new System.Windows.Forms.Label();
            this.labpri = new System.Windows.Forms.Label();
            this.labbooknam = new System.Windows.Forms.Label();
            this.cutbtn = new System.Windows.Forms.Label();
            this.lblauthorname = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.adresstextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bookslistbox
            // 
            this.bookslistbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookslistbox.FormattingEnabled = true;
            this.bookslistbox.Location = new System.Drawing.Point(58, 113);
            this.bookslistbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bookslistbox.Name = "bookslistbox";
            this.bookslistbox.Size = new System.Drawing.Size(396, 436);
            this.bookslistbox.TabIndex = 1;
            this.bookslistbox.SelectedIndexChanged += new System.EventHandler(this.bookslistbox_SelectedIndexChanged);
            // 
            // searchtextbox
            // 
            this.searchtextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchtextbox.Location = new System.Drawing.Point(58, 44);
            this.searchtextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchtextbox.Name = "searchtextbox";
            this.searchtextbox.Size = new System.Drawing.Size(408, 35);
            this.searchtextbox.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(371, 82);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 9;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // searchbtn
            // 
            this.searchbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbtn.Location = new System.Drawing.Point(487, 44);
            this.searchbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(112, 38);
            this.searchbtn.TabIndex = 10;
            this.searchbtn.Text = "search ";
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // alabano
            // 
            this.alabano.AutoSize = true;
            this.alabano.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabano.Location = new System.Drawing.Point(926, 304);
            this.alabano.Name = "alabano";
            this.alabano.Size = new System.Drawing.Size(160, 29);
            this.alabano.TabIndex = 100;
            this.alabano.Text = "                     ";
            // 
            // alabpri
            // 
            this.alabpri.AutoSize = true;
            this.alabpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabpri.Location = new System.Drawing.Point(810, 257);
            this.alabpri.Name = "alabpri";
            this.alabpri.Size = new System.Drawing.Size(139, 29);
            this.alabpri.TabIndex = 99;
            this.alabpri.Text = "                  ";
            // 
            // alabcat
            // 
            this.alabcat.AutoSize = true;
            this.alabcat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabcat.Location = new System.Drawing.Point(878, 206);
            this.alabcat.Name = "alabcat";
            this.alabcat.Size = new System.Drawing.Size(188, 29);
            this.alabcat.TabIndex = 97;
            this.alabcat.Text = "                         ";
            // 
            // alabautname
            // 
            this.alabautname.AutoSize = true;
            this.alabautname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabautname.Location = new System.Drawing.Point(878, 147);
            this.alabautname.Name = "alabautname";
            this.alabautname.Size = new System.Drawing.Size(160, 29);
            this.alabautname.TabIndex = 96;
            this.alabautname.Text = "                     ";
            // 
            // alabbookname
            // 
            this.alabbookname.AutoSize = true;
            this.alabbookname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabbookname.Location = new System.Drawing.Point(878, 91);
            this.alabbookname.Name = "alabbookname";
            this.alabbookname.Size = new System.Drawing.Size(209, 29);
            this.alabbookname.TabIndex = 95;
            this.alabbookname.Text = "                            ";
            // 
            // domamo
            // 
            this.domamo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.domamo.Location = new System.Drawing.Point(1012, 364);
            this.domamo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.domamo.Name = "domamo";
            this.domamo.Size = new System.Drawing.Size(207, 35);
            this.domamo.TabIndex = 94;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(707, 370);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(207, 29);
            this.label5.TabIndex = 93;
            this.label5.Text = "Amount of books";
            // 
            // labamo
            // 
            this.labamo.AutoSize = true;
            this.labamo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labamo.Location = new System.Drawing.Point(707, 304);
            this.labamo.Name = "labamo";
            this.labamo.Size = new System.Drawing.Size(210, 29);
            this.labamo.TabIndex = 92;
            this.labamo.Text = "Amount in stock :";
            // 
            // labpri
            // 
            this.labpri.AutoSize = true;
            this.labpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpri.Location = new System.Drawing.Point(707, 257);
            this.labpri.Name = "labpri";
            this.labpri.Size = new System.Drawing.Size(81, 29);
            this.labpri.TabIndex = 91;
            this.labpri.Text = "Price:";
            // 
            // labbooknam
            // 
            this.labbooknam.AutoSize = true;
            this.labbooknam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labbooknam.Location = new System.Drawing.Point(701, 91);
            this.labbooknam.Name = "labbooknam";
            this.labbooknam.Size = new System.Drawing.Size(165, 29);
            this.labbooknam.TabIndex = 90;
            this.labbooknam.Text = "Book name : ";
            // 
            // cutbtn
            // 
            this.cutbtn.AutoSize = true;
            this.cutbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cutbtn.Location = new System.Drawing.Point(701, 206);
            this.cutbtn.Name = "cutbtn";
            this.cutbtn.Size = new System.Drawing.Size(139, 29);
            this.cutbtn.TabIndex = 88;
            this.cutbtn.Text = "Category : ";
            // 
            // lblauthorname
            // 
            this.lblauthorname.AutoSize = true;
            this.lblauthorname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblauthorname.Location = new System.Drawing.Point(701, 147);
            this.lblauthorname.Name = "lblauthorname";
            this.lblauthorname.Size = new System.Drawing.Size(180, 29);
            this.lblauthorname.TabIndex = 87;
            this.lblauthorname.Text = "Author name : ";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1057, 496);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 70);
            this.button3.TabIndex = 86;
            this.button3.Text = "Order";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // adresstextbox
            // 
            this.adresstextbox.Location = new System.Drawing.Point(601, 496);
            this.adresstextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.adresstextbox.Name = "adresstextbox";
            this.adresstextbox.Size = new System.Drawing.Size(414, 26);
            this.adresstextbox.TabIndex = 101;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(523, 446);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(583, 29);
            this.label1.TabIndex = 102;
            this.label1.Text = "please insert full adress : city,street,house numer";
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.adresstextbox);
            this.Controls.Add(this.alabano);
            this.Controls.Add(this.alabpri);
            this.Controls.Add(this.alabcat);
            this.Controls.Add(this.alabautname);
            this.Controls.Add(this.alabbookname);
            this.Controls.Add(this.domamo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labamo);
            this.Controls.Add(this.labpri);
            this.Controls.Add(this.labbooknam);
            this.Controls.Add(this.cutbtn);
            this.Controls.Add(this.lblauthorname);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.searchbtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.searchtextbox);
            this.Controls.Add(this.bookslistbox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1778, 752);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(1422, 752);
            this.Load += new System.EventHandler(this.UserControl1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox bookslistbox;
        private System.Windows.Forms.TextBox searchtextbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.Label alabano;
        private System.Windows.Forms.Label alabpri;
        private System.Windows.Forms.Label alabcat;
        private System.Windows.Forms.Label alabautname;
        private System.Windows.Forms.Label alabbookname;
        private System.Windows.Forms.DomainUpDown domamo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labamo;
        private System.Windows.Forms.Label labpri;
        private System.Windows.Forms.Label labbooknam;
        private System.Windows.Forms.Label cutbtn;
        private System.Windows.Forms.Label lblauthorname;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox adresstextbox;
        private System.Windows.Forms.Label label1;
    }
}
