﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.ControlerPags
{
    public partial class UserControl1 : UserControl
    {

        public UserControl1()
        {
            InitializeComponent();

            domamo.Items.Add("0");  //הזנת נתונים ב DEMAMO
            for (int i = 1; i <= 999999; i++)
            {
                domamo.Items.Add(i.ToString());
            }
            domamo.SelectedItem = "0";
        }


        private void UserControl1_Load(object sender, EventArgs e)
        {
            foreach (string book in Arrayb.bookslist)
            {

                bookslistbox.Items.Add(book);
            }
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {

            bookslistbox.Items.Clear();
            foreach (string book in Arrayb.bookslist)
            {

                bookslistbox.Items.Add(book);
            }
            string searchItem = searchtextbox.Text.ToLower();
            List<string> filteredBooks = new List<string>();
            foreach (string book in bookslistbox.Items)
            {
                if (book.ToLower().StartsWith(searchItem))
                {
                    filteredBooks.Add(book);
                }
            }
            displaybooks(filteredBooks);

        }
        private void displaybooks(List<string> filteredBooks)
        {
            bookslistbox.Items.Clear();
            foreach (string book in filteredBooks)
            {
                bookslistbox.Items.Add(book);
            }

        }

        private void bookslistbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string bookname = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/Bookname");
                alabbookname.Text = bookname;
                alabautname.Text = Arrayb.autherslistpath[bookname].ToString();
                alabcat.Text = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/category");
                alabpri.Text = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/price");
                alabano.Text = File.ReadAllText((Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/amount"));
            }
            catch { }
        }
        private bool isadressvalid(string adress)
        {
            string userInputAdress = adress;
            if (string.IsNullOrEmpty(userInputAdress))
            {

                MessageBox.Show("Please enter an address.");
                return false;
            }
            else
            {
                string[] adressParts = userInputAdress.Split(',');
                if (adressParts.Length == 3)
                {
                    string city = adressParts[0];
                    string street = adressParts[1];
                    string housenumber = adressParts[2];
                    if (string.IsNullOrEmpty(city) || string.IsNullOrEmpty(street) || string.IsNullOrEmpty(housenumber))
                    {
                        MessageBox.Show("Please make sure all parts of the address are filled in correctly.");
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    MessageBox.Show("Please make sure all parts of the address are filled in correctly.");
                    return false;
                }
            }


        }



        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                int amountOfOrder = int.Parse(domamo.Text);
                int amountInStock = int.Parse(alabano.Text);
                if (amountOfOrder > amountInStock)
                {
                    MessageBox.Show("cannot order more book then the amount in the stock");
                }
                else if (!isadressvalid(adresstextbox.Text))
                {

                }
                else if (domamo.Text == "0")
                {
                    MessageBox.Show("cannot order 0 products ");
                }
                else
                {

                    string bookname = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/Bookname");
                    int counter = 1;
                    string newdirectoypath;
                    while (true)
                    {
                        newdirectoypath = Path.Combine("authors/" + Arrayb.autherslistid[Arrayb.autherslistpath[bookname].ToString()] + "/ordersFromMe/", counter.ToString());
                        if (!Directory.Exists(newdirectoypath))
                        {
                            Directory.CreateDirectory(newdirectoypath);
                            break;
                        }
                        counter++;
                    }
                    int price = int.Parse(alabpri.Text);

                    int result = price * amountOfOrder;
                    string finalResult = result.ToString();
                    int NewAmountInStock = amountInStock - amountOfOrder;
                    string FinalAmountInStock = NewAmountInStock.ToString();
                    File.AppendAllText(newdirectoypath + "/Bookname", bookname);
                    File.AppendAllText(newdirectoypath + "/category", alabcat.Text);
                    File.AppendAllText(newdirectoypath + "/amount", domamo.Text);
                    File.AppendAllText(newdirectoypath + "/addres", adresstextbox.Text);
                    File.AppendAllText(newdirectoypath + "/total order price", finalResult);
                    File.WriteAllText("authors/" + Arrayb.autherslistid[Arrayb.autherslistpath[bookname].ToString()] + "/books/" + bookname + "/amount", FinalAmountInStock);
                    MessageBox.Show($"Your purchase was completed successfully.the price : {result}");

                    //מרפרש מחדש את רשימת הספרים
                    string bookname1 = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/Bookname");
                    alabbookname.Text = bookname1;
                    alabautname.Text = Arrayb.autherslistpath[bookname1].ToString();
                    alabcat.Text = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/category");
                    alabpri.Text = File.ReadAllText(Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/price");
                    alabano.Text = File.ReadAllText((Arrayb.bookslistpath[bookslistbox.SelectedItem].ToString() + "/amount"));


                }
            }
            catch (Exception)
            {
                MessageBox.Show("To select a number please use only the arrows");
                domamo.SelectedItem = "0";

            }






        }
    }
}
