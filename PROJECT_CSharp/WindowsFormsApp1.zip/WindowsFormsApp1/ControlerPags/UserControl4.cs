﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.ControlerPags
{


    public partial class UserControl4 : UserControl
    {

        Books book1 = new Books();
        bool confirmname;
        string id;
        public UserControl4(string id)
        {
            InitializeComponent();
            this.id = id;
            domamo.Items.Add("0");
            for (int i = 1; i <= 999999; i++)
            {
                domamo.Items.Add(i.ToString());
            }
            domamo.SelectedItem = "0";

            dompri.Items.Add("0");
            for (int i = 1; i <= 9999; i++)
            {
                dompri.Items.Add(i.ToString());
            }
            dompri.SelectedItem = "0";

            foreach (Category category in Enum.GetValues(typeof(Category)))
            {

                catcomboBox.Items.Add(category);
            }

            catcomboBox.SelectedIndex = 0;
        }



        private void catcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (catcomboBox.SelectedItem is Category selectedCategory)
            {
                book1.Category = selectedCategory.ToString();
            }
        }


        private void butadd_Click_1(object sender, EventArgs e)
        {
            try
            {
                confirmname = book1.checkname(texnam.Text);
                if (float.Parse(dompri.SelectedItem.ToString()) > 0 && int.Parse(domamo.SelectedItem.ToString()) > 0 && catcomboBox.ToString() != "" && confirmname == true)
                {

                    book1.Bookname = texnam.Text;
                    book1.Price = float.Parse(dompri.SelectedItem.ToString());
                    book1.Amount = int.Parse(domamo.SelectedItem.ToString());
                    book1.Aboutbook = texabu.Text;
                    book1.addproduct(this.id);
                    MessageBox.Show("the book is published seccsefully ");
                    Arrayb.arrybookslaod();
                    laodbookslisti();
                    //איפוס
                    texnam.Text = "";
                    texabu.Text = "";
                    domamo.SelectedItem = "0";
                    dompri.SelectedItem = "0";
                }


            }
            catch (Exception)
            {
                domamo.SelectedItem = "0";
                dompri.SelectedItem = "0";
                MessageBox.Show("To select a number please use only the arrows");

            }

        }

        private void texnam_Leave(object sender, EventArgs e)
        {

            confirmname = book1.checkname(texnam.Text);
            if (confirmname == false)
            {
                labnam.Visible = true;
            }
            else
            {
                labnam.Visible = false;
            }
        }


        private void bookslistbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                button3.Visible = true;
                alabbookname.Text = File.ReadAllText("authors/" + id + "/books/" + bookslistbox.SelectedItem + "/Bookname");
                alabcat.Text = File.ReadAllText("authors/" + id + "/books/" + bookslistbox.SelectedItem + "/category");
                alabpri.Text = File.ReadAllText("authors/" + id + "/books/" + bookslistbox.SelectedItem + "/price");
                alabano.Text = File.ReadAllText("authors/" + id + "/books/" + bookslistbox.SelectedItem + "/amount");
            }
            catch { }
        }

        private void UserControl4_Load(object sender, EventArgs e)
        {
            laodbookslisti();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Directory.Delete("authors/" + id + "/books/" + bookslistbox.SelectedItem, true);
            Arrayb.arrybookslaod();
            laodbookslisti();
            button3.Visible = false;

        }

        private void laodbookslisti()
        {
            bookslistbox.Items.Clear();
            string[] values = (string[])Arrayb.idbookspath[id];
            int counter = values.Count();
            for (int i = 0; i < counter; i++)
            {
                bookslistbox.Items.Add(Path.GetFileName(values[i]));


            }
        }
    }
}
