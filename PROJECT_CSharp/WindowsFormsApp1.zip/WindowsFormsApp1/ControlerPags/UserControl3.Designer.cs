﻿namespace WindowsFormsApp1.ControlerPags
{
    partial class UserControl3
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butsen = new System.Windows.Forms.Button();
            this.alabadd = new System.Windows.Forms.Label();
            this.labadd = new System.Windows.Forms.Label();
            this.alabpri = new System.Windows.Forms.Label();
            this.labpri = new System.Windows.Forms.Label();
            this.alabcat = new System.Windows.Forms.Label();
            this.cutbtn = new System.Windows.Forms.Label();
            this.alabano = new System.Windows.Forms.Label();
            this.labamo = new System.Windows.Forms.Label();
            this.alabbookname = new System.Windows.Forms.Label();
            this.labbooknam = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bookslistbox = new System.Windows.Forms.CheckedListBox();
            this.SuspendLayout();
            // 
            // butsen
            // 
            this.butsen.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butsen.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.butsen.Location = new System.Drawing.Point(749, 388);
            this.butsen.Name = "butsen";
            this.butsen.Size = new System.Drawing.Size(116, 38);
            this.butsen.TabIndex = 122;
            this.butsen.Text = "Sended";
            this.butsen.UseVisualStyleBackColor = true;
            this.butsen.Visible = false;
            this.butsen.Click += new System.EventHandler(this.butsen_Click);
            // 
            // alabadd
            // 
            this.alabadd.AutoSize = true;
            this.alabadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabadd.Location = new System.Drawing.Point(758, 327);
            this.alabadd.Name = "alabadd";
            this.alabadd.Size = new System.Drawing.Size(139, 29);
            this.alabadd.TabIndex = 121;
            this.alabadd.Text = "                  ";
            // 
            // labadd
            // 
            this.labadd.AutoSize = true;
            this.labadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labadd.Location = new System.Drawing.Point(655, 327);
            this.labadd.Name = "labadd";
            this.labadd.Size = new System.Drawing.Size(103, 29);
            this.labadd.TabIndex = 120;
            this.labadd.Text = "Addres:";
            // 
            // alabpri
            // 
            this.alabpri.AutoSize = true;
            this.alabpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabpri.Location = new System.Drawing.Point(758, 277);
            this.alabpri.Name = "alabpri";
            this.alabpri.Size = new System.Drawing.Size(139, 29);
            this.alabpri.TabIndex = 119;
            this.alabpri.Text = "                  ";
            // 
            // labpri
            // 
            this.labpri.AutoSize = true;
            this.labpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpri.Location = new System.Drawing.Point(655, 277);
            this.labpri.Name = "labpri";
            this.labpri.Size = new System.Drawing.Size(81, 29);
            this.labpri.TabIndex = 118;
            this.labpri.Text = "Price:";
            // 
            // alabcat
            // 
            this.alabcat.AutoSize = true;
            this.alabcat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabcat.Location = new System.Drawing.Point(832, 224);
            this.alabcat.Name = "alabcat";
            this.alabcat.Size = new System.Drawing.Size(188, 29);
            this.alabcat.TabIndex = 117;
            this.alabcat.Text = "                         ";
            // 
            // cutbtn
            // 
            this.cutbtn.AutoSize = true;
            this.cutbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cutbtn.Location = new System.Drawing.Point(655, 224);
            this.cutbtn.Name = "cutbtn";
            this.cutbtn.Size = new System.Drawing.Size(139, 29);
            this.cutbtn.TabIndex = 116;
            this.cutbtn.Text = "Category : ";
            // 
            // alabano
            // 
            this.alabano.AutoSize = true;
            this.alabano.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabano.Location = new System.Drawing.Point(874, 169);
            this.alabano.Name = "alabano";
            this.alabano.Size = new System.Drawing.Size(160, 29);
            this.alabano.TabIndex = 115;
            this.alabano.Text = "                     ";
            // 
            // labamo
            // 
            this.labamo.AutoSize = true;
            this.labamo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labamo.Location = new System.Drawing.Point(655, 169);
            this.labamo.Name = "labamo";
            this.labamo.Size = new System.Drawing.Size(210, 29);
            this.labamo.TabIndex = 114;
            this.labamo.Text = "Amount in stock :";
            // 
            // alabbookname
            // 
            this.alabbookname.AutoSize = true;
            this.alabbookname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabbookname.Location = new System.Drawing.Point(832, 110);
            this.alabbookname.Name = "alabbookname";
            this.alabbookname.Size = new System.Drawing.Size(209, 29);
            this.alabbookname.TabIndex = 113;
            this.alabbookname.Text = "                            ";
            // 
            // labbooknam
            // 
            this.labbooknam.AutoSize = true;
            this.labbooknam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labbooknam.Location = new System.Drawing.Point(655, 110);
            this.labbooknam.Name = "labbooknam";
            this.labbooknam.Size = new System.Drawing.Size(165, 29);
            this.labbooknam.TabIndex = 112;
            this.labbooknam.Text = "Book name : ";
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(151, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(377, 48);
            this.label1.TabIndex = 111;
            this.label1.Text = "Ordered From Me";
            // 
            // bookslistbox
            // 
            this.bookslistbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookslistbox.FormattingEnabled = true;
            this.bookslistbox.Location = new System.Drawing.Point(157, 109);
            this.bookslistbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bookslistbox.Name = "bookslistbox";
            this.bookslistbox.Size = new System.Drawing.Size(314, 436);
            this.bookslistbox.TabIndex = 110;
            this.bookslistbox.SelectedIndexChanged += new System.EventHandler(this.bookslistbox_SelectedIndexChanged);
            // 
            // UserControl3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.butsen);
            this.Controls.Add(this.alabadd);
            this.Controls.Add(this.labadd);
            this.Controls.Add(this.alabpri);
            this.Controls.Add(this.labpri);
            this.Controls.Add(this.alabcat);
            this.Controls.Add(this.cutbtn);
            this.Controls.Add(this.alabano);
            this.Controls.Add(this.labamo);
            this.Controls.Add(this.alabbookname);
            this.Controls.Add(this.labbooknam);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bookslistbox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1778, 752);
            this.Name = "UserControl3";
            this.Size = new System.Drawing.Size(1778, 752);
            this.Load += new System.EventHandler(this.UserControl3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox bookslistbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butsen;
        private System.Windows.Forms.Label alabadd;
        private System.Windows.Forms.Label labadd;
        private System.Windows.Forms.Label alabpri;
        private System.Windows.Forms.Label labpri;
        private System.Windows.Forms.Label alabcat;
        private System.Windows.Forms.Label cutbtn;
        private System.Windows.Forms.Label alabano;
        private System.Windows.Forms.Label labamo;
        private System.Windows.Forms.Label alabbookname;
        private System.Windows.Forms.Label labbooknam;
    }
}
