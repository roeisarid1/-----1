﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.ControlerPags
{
    public partial class UserControl3 : UserControl
    {

        string id;
        bool sended;
        public UserControl3(string id)
        {
            InitializeComponent();
            this.id = id;

        }



        /// <summary>
        /// .במחלקה זאת לעשות לולאה דרך הקבצים שיצרתי שתציג לסופר את כל ההזמנות שהזמינו ממנו
        /// .המחלקה עובדת על אותו עקרון הרשאה רק לסופרים
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void UserControl3_Load(object sender, EventArgs e)
        {

            int counter = 1;
            string newdirectoypath;
            while (true)
            {
                newdirectoypath = Path.Combine("authors/" + id + "/ordersFromMe/", counter.ToString());
                if (Directory.Exists(newdirectoypath))
                {

                    bookslistbox.Items.Add(counter.ToString());

                }
                else { break; }
                counter++;
            }
        }





        private void bookslistbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            butsen.Visible = true;
            ifsended();
            if (sended) { butsen.BackColor = Color.Red; }
            else {  butsen.BackColor = Color.White; }
            alabbookname.Text = File.ReadAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem + "/Bookname");
            alabcat.Text = File.ReadAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem + "/category");
            alabpri.Text = File.ReadAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem + "/total order price");
            alabano.Text = File.ReadAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem + "/amount");
            alabadd.Text = File.ReadAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem + "/addres");

        }

        private void butsen_Click(object sender, EventArgs e)
        {
            if (!sended)
            {
                File.AppendAllText("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem.ToString() + "/sended", "sended");
                butsen.BackColor = Color.Red;
            }

        }
        private void ifsended()
        {

            string newdirectoypath;
            newdirectoypath = Path.Combine("authors/" + id + "/ordersFromMe/" + bookslistbox.SelectedItem.ToString() + "/sended");
            if (!File.Exists(newdirectoypath))
            {
                sended = false;
            }
            else
            {
                sended = true;
            }

        }
    }
}
