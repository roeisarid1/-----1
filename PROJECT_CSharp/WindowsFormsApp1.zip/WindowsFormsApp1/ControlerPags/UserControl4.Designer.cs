﻿namespace WindowsFormsApp1.ControlerPags
{
    partial class UserControl4
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.labpri = new System.Windows.Forms.Label();
            this.categorylbl = new System.Windows.Forms.Label();
            this.booknamelbl = new System.Windows.Forms.Label();
            this.texnam = new System.Windows.Forms.TextBox();
            this.dompri = new System.Windows.Forms.DomainUpDown();
            this.domamo = new System.Windows.Forms.DomainUpDown();
            this.labשנם = new System.Windows.Forms.Label();
            this.texabu = new System.Windows.Forms.TextBox();
            this.catcomboBox = new System.Windows.Forms.ComboBox();
            this.butadd = new System.Windows.Forms.Button();
            this.labnam = new System.Windows.Forms.Label();
            this.bookslistbox = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.alabano = new System.Windows.Forms.Label();
            this.alabpri = new System.Windows.Forms.Label();
            this.alabcat = new System.Windows.Forms.Label();
            this.alabbookname = new System.Windows.Forms.Label();
            this.labamo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labbooknam = new System.Windows.Forms.Label();
            this.cutbtn = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(60, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 29);
            this.label5.TabIndex = 61;
            this.label5.Text = "Amount";
            // 
            // labpri
            // 
            this.labpri.AutoSize = true;
            this.labpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpri.Location = new System.Drawing.Point(60, 295);
            this.labpri.Name = "labpri";
            this.labpri.Size = new System.Drawing.Size(169, 29);
            this.labpri.TabIndex = 59;
            this.labpri.Text = "Price per unit";
            // 
            // categorylbl
            // 
            this.categorylbl.AutoSize = true;
            this.categorylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categorylbl.Location = new System.Drawing.Point(62, 165);
            this.categorylbl.Name = "categorylbl";
            this.categorylbl.Size = new System.Drawing.Size(125, 29);
            this.categorylbl.TabIndex = 58;
            this.categorylbl.Text = "Category ";
            // 
            // booknamelbl
            // 
            this.booknamelbl.AutoSize = true;
            this.booknamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booknamelbl.Location = new System.Drawing.Point(62, 102);
            this.booknamelbl.Name = "booknamelbl";
            this.booknamelbl.Size = new System.Drawing.Size(82, 29);
            this.booknamelbl.TabIndex = 57;
            this.booknamelbl.Text = "Name";
            // 
            // texnam
            // 
            this.texnam.Location = new System.Drawing.Point(305, 106);
            this.texnam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texnam.Name = "texnam";
            this.texnam.Size = new System.Drawing.Size(272, 26);
            this.texnam.TabIndex = 51;
            this.texnam.Leave += new System.EventHandler(this.texnam_Leave);
            // 
            // dompri
            // 
            this.dompri.Location = new System.Drawing.Point(305, 300);
            this.dompri.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dompri.Name = "dompri";
            this.dompri.Size = new System.Drawing.Size(272, 26);
            this.dompri.TabIndex = 76;
            this.dompri.Text = "domainUpDown1";
            // 
            // domamo
            // 
            this.domamo.Location = new System.Drawing.Point(305, 236);
            this.domamo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.domamo.Name = "domamo";
            this.domamo.Size = new System.Drawing.Size(272, 26);
            this.domamo.TabIndex = 77;
            this.domamo.Text = "domainUpDown2";
            // 
            // labשנם
            // 
            this.labשנם.AutoSize = true;
            this.labשנם.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labשנם.Location = new System.Drawing.Point(62, 359);
            this.labשנם.Name = "labשנם";
            this.labשנם.Size = new System.Drawing.Size(188, 29);
            this.labשנם.TabIndex = 79;
            this.labשנם.Text = "About the book";
            // 
            // texabu
            // 
            this.texabu.Location = new System.Drawing.Point(305, 363);
            this.texabu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texabu.Name = "texabu";
            this.texabu.Size = new System.Drawing.Size(272, 26);
            this.texabu.TabIndex = 78;
            // 
            // catcomboBox
            // 
            this.catcomboBox.FormattingEnabled = true;
            this.catcomboBox.Location = new System.Drawing.Point(315, 169);
            this.catcomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.catcomboBox.Name = "catcomboBox";
            this.catcomboBox.Size = new System.Drawing.Size(262, 28);
            this.catcomboBox.TabIndex = 83;
            this.catcomboBox.SelectedIndexChanged += new System.EventHandler(this.catcomboBox_SelectedIndexChanged);
            // 
            // butadd
            // 
            this.butadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butadd.Location = new System.Drawing.Point(378, 431);
            this.butadd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butadd.Name = "butadd";
            this.butadd.Size = new System.Drawing.Size(199, 38);
            this.butadd.TabIndex = 84;
            this.butadd.Text = "Add a product";
            this.butadd.UseVisualStyleBackColor = true;
            this.butadd.Click += new System.EventHandler(this.butadd_Click_1);
            // 
            // labnam
            // 
            this.labnam.AutoSize = true;
            this.labnam.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labnam.ForeColor = System.Drawing.Color.Red;
            this.labnam.Location = new System.Drawing.Point(470, 134);
            this.labnam.Name = "labnam";
            this.labnam.Size = new System.Drawing.Size(106, 20);
            this.labnam.TabIndex = 85;
            this.labnam.Text = "Name exists";
            this.labnam.Visible = false;
            // 
            // bookslistbox
            // 
            this.bookslistbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookslistbox.FormattingEnabled = true;
            this.bookslistbox.Location = new System.Drawing.Point(680, 98);
            this.bookslistbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bookslistbox.Name = "bookslistbox";
            this.bookslistbox.Size = new System.Drawing.Size(396, 517);
            this.bookslistbox.TabIndex = 86;
            this.bookslistbox.SelectedIndexChanged += new System.EventHandler(this.bookslistbox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(674, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 35);
            this.label1.TabIndex = 87;
            this.label1.Text = "My Books";
            // 
            // alabano
            // 
            this.alabano.AutoSize = true;
            this.alabano.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabano.Location = new System.Drawing.Point(1346, 241);
            this.alabano.Name = "alabano";
            this.alabano.Size = new System.Drawing.Size(160, 29);
            this.alabano.TabIndex = 110;
            this.alabano.Text = "                     ";
            // 
            // alabpri
            // 
            this.alabpri.AutoSize = true;
            this.alabpri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabpri.Location = new System.Drawing.Point(1230, 194);
            this.alabpri.Name = "alabpri";
            this.alabpri.Size = new System.Drawing.Size(139, 29);
            this.alabpri.TabIndex = 109;
            this.alabpri.Text = "                  ";
            // 
            // alabcat
            // 
            this.alabcat.AutoSize = true;
            this.alabcat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabcat.Location = new System.Drawing.Point(1298, 143);
            this.alabcat.Name = "alabcat";
            this.alabcat.Size = new System.Drawing.Size(188, 29);
            this.alabcat.TabIndex = 108;
            this.alabcat.Text = "                         ";
            // 
            // alabbookname
            // 
            this.alabbookname.AutoSize = true;
            this.alabbookname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alabbookname.Location = new System.Drawing.Point(1298, 98);
            this.alabbookname.Name = "alabbookname";
            this.alabbookname.Size = new System.Drawing.Size(209, 29);
            this.alabbookname.TabIndex = 106;
            this.alabbookname.Text = "                            ";
            // 
            // labamo
            // 
            this.labamo.AutoSize = true;
            this.labamo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labamo.Location = new System.Drawing.Point(1127, 241);
            this.labamo.Name = "labamo";
            this.labamo.Size = new System.Drawing.Size(210, 29);
            this.labamo.TabIndex = 105;
            this.labamo.Text = "Amount in stock :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1127, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 29);
            this.label2.TabIndex = 104;
            this.label2.Text = "Price:";
            // 
            // labbooknam
            // 
            this.labbooknam.AutoSize = true;
            this.labbooknam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labbooknam.Location = new System.Drawing.Point(1121, 98);
            this.labbooknam.Name = "labbooknam";
            this.labbooknam.Size = new System.Drawing.Size(165, 29);
            this.labbooknam.TabIndex = 103;
            this.labbooknam.Text = "Book name : ";
            // 
            // cutbtn
            // 
            this.cutbtn.AutoSize = true;
            this.cutbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cutbtn.Location = new System.Drawing.Point(1121, 143);
            this.cutbtn.Name = "cutbtn";
            this.cutbtn.Size = new System.Drawing.Size(139, 29);
            this.cutbtn.TabIndex = 102;
            this.cutbtn.Text = "Category : ";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1303, 331);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 70);
            this.button3.TabIndex = 111;
            this.button3.Text = "delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // UserControl4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CausesValidation = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.alabano);
            this.Controls.Add(this.alabpri);
            this.Controls.Add(this.alabcat);
            this.Controls.Add(this.alabbookname);
            this.Controls.Add(this.labamo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labbooknam);
            this.Controls.Add(this.cutbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bookslistbox);
            this.Controls.Add(this.labnam);
            this.Controls.Add(this.butadd);
            this.Controls.Add(this.catcomboBox);
            this.Controls.Add(this.labשנם);
            this.Controls.Add(this.texabu);
            this.Controls.Add(this.domamo);
            this.Controls.Add(this.dompri);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labpri);
            this.Controls.Add(this.categorylbl);
            this.Controls.Add(this.booknamelbl);
            this.Controls.Add(this.texnam);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1778, 752);
            this.Name = "UserControl4";
            this.Size = new System.Drawing.Size(1778, 734);
            this.Load += new System.EventHandler(this.UserControl4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labpri;
        private System.Windows.Forms.Label categorylbl;
        private System.Windows.Forms.Label booknamelbl;
        private System.Windows.Forms.TextBox texnam;
        private System.Windows.Forms.DomainUpDown dompri;
        private System.Windows.Forms.DomainUpDown domamo;
        private System.Windows.Forms.Label labשנם;
        private System.Windows.Forms.TextBox texabu;
        private System.Windows.Forms.ComboBox catcomboBox;
        private System.Windows.Forms.Button butadd;
        private System.Windows.Forms.Label labnam;
        private System.Windows.Forms.CheckedListBox bookslistbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label alabano;
        private System.Windows.Forms.Label alabpri;
        private System.Windows.Forms.Label alabcat;
        private System.Windows.Forms.Label alabbookname;
        private System.Windows.Forms.Label labamo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labbooknam;
        private System.Windows.Forms.Label cutbtn;
        private System.Windows.Forms.Button button3;
    }
}
