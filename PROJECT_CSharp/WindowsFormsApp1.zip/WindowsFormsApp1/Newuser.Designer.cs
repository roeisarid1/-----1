﻿namespace WindowsFormsApp1
{
    partial class Newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butent = new System.Windows.Forms.Button();
            this.labid = new System.Windows.Forms.Label();
            this.datbir = new System.Windows.Forms.DateTimePicker();
            this.texID = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labpas = new System.Windows.Forms.Label();
            this.labful = new System.Windows.Forms.Label();
            this.labbir = new System.Windows.Forms.Label();
            this.texfir = new System.Windows.Forms.TextBox();
            this.texpas = new System.Windows.Forms.TextBox();
            this.cheaut = new System.Windows.Forms.CheckBox();
            this.labpascoa = new System.Windows.Forms.Label();
            this.texpascoa = new System.Windows.Forms.TextBox();
            this.FullNameNotValid = new System.Windows.Forms.Label();
            this.IdNotValid = new System.Windows.Forms.Label();
            this.labeid = new System.Windows.Forms.Label();
            this.DOBnotvalidlbl = new System.Windows.Forms.Label();
            this.confirnedbtn = new System.Windows.Forms.Button();
            this.confirmbtn = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.incorrectcode = new System.Windows.Forms.Label();
            this.btnaut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // butent
            // 
            this.butent.BackColor = System.Drawing.Color.DarkGray;
            this.butent.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butent.Location = new System.Drawing.Point(324, 440);
            this.butent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butent.Name = "butent";
            this.butent.Size = new System.Drawing.Size(127, 62);
            this.butent.TabIndex = 0;
            this.butent.Text = "Enter";
            this.butent.UseVisualStyleBackColor = false;
            this.butent.Click += new System.EventHandler(this.butent_Click);
            // 
            // labid
            // 
            this.labid.AutoSize = true;
            this.labid.Font = new System.Drawing.Font("Cascadia Mono", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labid.Location = new System.Drawing.Point(143, 172);
            this.labid.Name = "labid";
            this.labid.Size = new System.Drawing.Size(36, 27);
            this.labid.TabIndex = 2;
            this.labid.Text = "ID";
            // 
            // datbir
            // 
            this.datbir.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.datbir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datbir.Location = new System.Drawing.Point(324, 359);
            this.datbir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.datbir.Name = "datbir";
            this.datbir.Size = new System.Drawing.Size(324, 30);
            this.datbir.TabIndex = 3;
            // 
            // texID
            // 
            this.texID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texID.Location = new System.Drawing.Point(324, 170);
            this.texID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texID.Name = "texID";
            this.texID.Size = new System.Drawing.Size(324, 30);
            this.texID.TabIndex = 4;
            this.texID.Click += new System.EventHandler(this.texID_Click);
            this.texID.Leave += new System.EventHandler(this.texID_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1078, 108);
            this.panel1.TabIndex = 5;
            // 
            // labpas
            // 
            this.labpas.AutoSize = true;
            this.labpas.Font = new System.Drawing.Font("Cascadia Mono", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpas.Location = new System.Drawing.Point(143, 294);
            this.labpas.Name = "labpas";
            this.labpas.Size = new System.Drawing.Size(108, 27);
            this.labpas.TabIndex = 6;
            this.labpas.Text = "Password";
            // 
            // labful
            // 
            this.labful.AutoSize = true;
            this.labful.Font = new System.Drawing.Font("Cascadia Mono", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labful.Location = new System.Drawing.Point(143, 231);
            this.labful.Name = "labful";
            this.labful.Size = new System.Drawing.Size(120, 27);
            this.labful.TabIndex = 7;
            this.labful.Text = "Full Name";
            // 
            // labbir
            // 
            this.labbir.AutoSize = true;
            this.labbir.Font = new System.Drawing.Font("Cascadia Mono", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labbir.Location = new System.Drawing.Point(143, 359);
            this.labbir.Name = "labbir";
            this.labbir.Size = new System.Drawing.Size(108, 27);
            this.labbir.TabIndex = 8;
            this.labbir.Text = "Birthday";
            // 
            // texfir
            // 
            this.texfir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texfir.Location = new System.Drawing.Point(324, 228);
            this.texfir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texfir.Name = "texfir";
            this.texfir.Size = new System.Drawing.Size(324, 30);
            this.texfir.TabIndex = 9;
            this.texfir.Click += new System.EventHandler(this.texfir_Click_1);
            this.texfir.Leave += new System.EventHandler(this.texfir_Leave_1);
            // 
            // texpas
            // 
            this.texpas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texpas.Location = new System.Drawing.Point(324, 291);
            this.texpas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texpas.Name = "texpas";
            this.texpas.Size = new System.Drawing.Size(324, 30);
            this.texpas.TabIndex = 10;
            // 
            // cheaut
            // 
            this.cheaut.AutoSize = true;
            this.cheaut.Location = new System.Drawing.Point(324, 552);
            this.cheaut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cheaut.Name = "cheaut";
            this.cheaut.Size = new System.Drawing.Size(153, 24);
            this.cheaut.TabIndex = 13;
            this.cheaut.Text = "Author click here";
            this.cheaut.UseVisualStyleBackColor = true;
            this.cheaut.Click += new System.EventHandler(this.cheaut_Click);
            // 
            // labpascoa
            // 
            this.labpascoa.AutoSize = true;
            this.labpascoa.Font = new System.Drawing.Font("Cascadia Mono", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labpascoa.Location = new System.Drawing.Point(320, 590);
            this.labpascoa.Name = "labpascoa";
            this.labpascoa.Size = new System.Drawing.Size(312, 27);
            this.labpascoa.TabIndex = 14;
            this.labpascoa.Text = "Enter password for author";
            this.labpascoa.Visible = false;
            // 
            // texpascoa
            // 
            this.texpascoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texpascoa.Location = new System.Drawing.Point(324, 634);
            this.texpascoa.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.texpascoa.Name = "texpascoa";
            this.texpascoa.Size = new System.Drawing.Size(206, 30);
            this.texpascoa.TabIndex = 19;
            this.texpascoa.Visible = false;
            // 
            // FullNameNotValid
            // 
            this.FullNameNotValid.AutoSize = true;
            this.FullNameNotValid.ForeColor = System.Drawing.Color.Red;
            this.FullNameNotValid.Location = new System.Drawing.Point(670, 231);
            this.FullNameNotValid.Name = "FullNameNotValid";
            this.FullNameNotValid.Size = new System.Drawing.Size(155, 20);
            this.FullNameNotValid.TabIndex = 24;
            this.FullNameNotValid.Text = "Full name is not valid";
            // 
            // IdNotValid
            // 
            this.IdNotValid.AutoSize = true;
            this.IdNotValid.ForeColor = System.Drawing.Color.Red;
            this.IdNotValid.Location = new System.Drawing.Point(670, 182);
            this.IdNotValid.Name = "IdNotValid";
            this.IdNotValid.Size = new System.Drawing.Size(100, 20);
            this.IdNotValid.TabIndex = 25;
            this.IdNotValid.Text = "Id is not valid";
            // 
            // labeid
            // 
            this.labeid.AutoSize = true;
            this.labeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeid.ForeColor = System.Drawing.Color.Red;
            this.labeid.Location = new System.Drawing.Point(670, 161);
            this.labeid.Name = "labeid";
            this.labeid.Size = new System.Drawing.Size(76, 20);
            this.labeid.TabIndex = 26;
            this.labeid.Text = "Id exists";
            // 
            // DOBnotvalidlbl
            // 
            this.DOBnotvalidlbl.AutoSize = true;
            this.DOBnotvalidlbl.ForeColor = System.Drawing.Color.Red;
            this.DOBnotvalidlbl.Location = new System.Drawing.Point(321, 394);
            this.DOBnotvalidlbl.Name = "DOBnotvalidlbl";
            this.DOBnotvalidlbl.Size = new System.Drawing.Size(258, 20);
            this.DOBnotvalidlbl.TabIndex = 27;
            this.DOBnotvalidlbl.Text = "registration only from the age of 16 ";
            // 
            // confirnedbtn
            // 
            this.confirnedbtn.BackColor = System.Drawing.Color.Green;
            this.confirnedbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirnedbtn.Location = new System.Drawing.Point(76, 344);
            this.confirnedbtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.confirnedbtn.Name = "confirnedbtn";
            this.confirnedbtn.Size = new System.Drawing.Size(50, 54);
            this.confirnedbtn.TabIndex = 28;
            this.confirnedbtn.Text = "✔";
            this.confirnedbtn.UseVisualStyleBackColor = false;
            this.confirnedbtn.Visible = false;
            // 
            // confirmbtn
            // 
            this.confirmbtn.BackColor = System.Drawing.Color.Green;
            this.confirmbtn.ForeColor = System.Drawing.Color.White;
            this.confirmbtn.Location = new System.Drawing.Point(655, 359);
            this.confirmbtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.confirmbtn.Name = "confirmbtn";
            this.confirmbtn.Size = new System.Drawing.Size(168, 32);
            this.confirmbtn.TabIndex = 29;
            this.confirmbtn.Text = "press to confirm date";
            this.confirmbtn.UseVisualStyleBackColor = false;
            this.confirmbtn.Click += new System.EventHandler(this.confirmbtn_Click_1);
            // 
            // incorrectcode
            // 
            this.incorrectcode.AutoSize = true;
            this.incorrectcode.ForeColor = System.Drawing.Color.Red;
            this.incorrectcode.Location = new System.Drawing.Point(321, 688);
            this.incorrectcode.Name = "incorrectcode";
            this.incorrectcode.Size = new System.Drawing.Size(114, 20);
            this.incorrectcode.TabIndex = 30;
            this.incorrectcode.Text = "Incorrect Code";
            this.incorrectcode.Visible = false;
            // 
            // btnaut
            // 
            this.btnaut.BackColor = System.Drawing.Color.DarkGray;
            this.btnaut.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaut.Location = new System.Drawing.Point(324, 440);
            this.btnaut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnaut.Name = "btnaut";
            this.btnaut.Size = new System.Drawing.Size(127, 62);
            this.btnaut.TabIndex = 31;
            this.btnaut.Text = "Enter";
            this.btnaut.UseVisualStyleBackColor = false;
            this.btnaut.Visible = false;
            this.btnaut.Click += new System.EventHandler(this.btnaut_Click);
            // 
            // Newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 741);
            this.Controls.Add(this.btnaut);
            this.Controls.Add(this.incorrectcode);
            this.Controls.Add(this.confirmbtn);
            this.Controls.Add(this.confirnedbtn);
            this.Controls.Add(this.DOBnotvalidlbl);
            this.Controls.Add(this.labeid);
            this.Controls.Add(this.IdNotValid);
            this.Controls.Add(this.FullNameNotValid);
            this.Controls.Add(this.texpascoa);
            this.Controls.Add(this.labpascoa);
            this.Controls.Add(this.cheaut);
            this.Controls.Add(this.texpas);
            this.Controls.Add(this.texfir);
            this.Controls.Add(this.labbir);
            this.Controls.Add(this.labful);
            this.Controls.Add(this.labpas);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.texID);
            this.Controls.Add(this.datbir);
            this.Controls.Add(this.labid);
            this.Controls.Add(this.butent);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1100, 797);
            this.Name = "Newuser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Newuser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butent;
        private System.Windows.Forms.Label labid;
        private System.Windows.Forms.DateTimePicker datbir;
        private System.Windows.Forms.TextBox texID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labpas;
        private System.Windows.Forms.Label labful;
        private System.Windows.Forms.Label labbir;
        private System.Windows.Forms.TextBox texfir;
        private System.Windows.Forms.TextBox texpas;
        private System.Windows.Forms.CheckBox cheaut;
        private System.Windows.Forms.Label labpascoa;
        private System.Windows.Forms.TextBox texpascoa;
        private System.Windows.Forms.Label FullNameNotValid;
        private System.Windows.Forms.Label IdNotValid;
        private System.Windows.Forms.Label labeid;
        private System.Windows.Forms.Label DOBnotvalidlbl;
        private System.Windows.Forms.Button confirnedbtn;
        private System.Windows.Forms.Button confirmbtn;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label incorrectcode;
        private System.Windows.Forms.Button btnaut;
    }
}